from django.apps import AppConfig


class WoodConfig(AppConfig):
    name = 'wood'
